# config.py
OPENAI_API_KEY = "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"
