# config.py
OPENAI_API_KEY = "Your api key"
